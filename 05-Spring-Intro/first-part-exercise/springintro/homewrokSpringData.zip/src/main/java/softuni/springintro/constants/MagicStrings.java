package softuni.springintro.constants;

public class MagicStrings {
    public final static String FIRST_TASK = String.format("%n FIRST task processing: %n");
    public final static String SECOND_TASK = String.format("%n SECOND task processing: %n");
    public final static String THIRD_TASK = String.format("%n THIRD task processing: %n");
    public final static String FOURTH_TASK = String.format("%n FOURTH task processing: %n");
}
