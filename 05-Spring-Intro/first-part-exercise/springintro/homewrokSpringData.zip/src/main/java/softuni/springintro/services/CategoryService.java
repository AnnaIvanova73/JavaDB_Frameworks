package softuni.springintro.services;

import java.io.IOException;
import java.util.List;

public interface CategoryService {

    void seedCategory() throws IOException;

}
