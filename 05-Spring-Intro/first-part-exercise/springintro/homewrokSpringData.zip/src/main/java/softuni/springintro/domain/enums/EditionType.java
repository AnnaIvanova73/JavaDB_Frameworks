package softuni.springintro.domain.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
