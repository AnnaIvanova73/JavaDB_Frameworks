package softuni.springintro.domain.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
